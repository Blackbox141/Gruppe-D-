# Project_Structure
This repository has the structure for to create an application with a single entry point.
This structure will be updated from time to time, please watch the commits.